//Calculates resistance of n-tier electric circuit
#include <stdio.h>
#include <conio.h>
#include <iostream>

float r1, r2, r3; //the resistances of which chain comprises
//calculates the resistance of the chain n-th order
float rcep(int n)
{
	float r; //resistance of the chain of order n-1 
		if (n == 1)
			return(r1 + r2 + r3);
		else
		{
			r = rcep(n-1);
			return (r1 + r2*r / (r2 + r) + r3);
		}
}
void main()
{
	system ("color F0");
	int n; //number of units (the order) of the chain
	float rc; //resistance of the chain
	puts("Calculation the resistance of the circuit ");
	puts("Enter the value of the resistance (Ohms):");
	printf("r1 ->");
	scanf("%f", &r1);
	printf("�2 ->");
	scanf("%f", &r2);
	printf("r3 ->");
	scanf("%f", &r3);
	printf("The order of the chain ->");
	scanf("%i", &n);
	rc = rcep(n); //the resistances are transmitted
	// to the function rcep through global variables
	printf("The resistance of the circuit:");
	if (rc > 100)
	{
		rc /= 1000;
		printf("%5.2f kOhms\n", rc);
	}
	else
		printf("%5.2f Ohms\n", rc);
	puts("\nClick <Enter> to complete");
	getch();
}