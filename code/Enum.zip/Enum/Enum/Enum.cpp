#include <iostream>
using namespace std;

//gefine enum
enum level { parking, supermarket, hardwareStores, boutiques, sportSpa, clubRestaurantBar };

int main()
{
	system("color F0");

	level floor = parking;//value of level type
	int fl = floor;//user's choice of floor
	bool exit = true;//user's choice - exit and continue
	cout << "Welcome to our shopping MALL!!!\n";
	cout << "We are offering you to ride on the elevator and visit all the floors!\n";

	while (exit)//���� exit ����� true
	{
		puts("\nInput number of floor (from 0 to 5): ");
		cin >> fl;

		switch (fl)
		{
		case(parking) :
			cout << "\aYou are in the parking!!!" << endl;
			break;

		case(supermarket) :
			cout << "\aYou are on the first floor!";
			cout << "\nThere you can go to the supermarket and buy products or things for home.\n\n";
			break;

		case(hardwareStores) :
			cout << "\aYou are on the second floor!";
			cout << "\nThere are technical shops.\n\n";
			break;

		case(boutiques) :
			cout << "\aYou are on the third floor!";
			cout << "\nThere you can have a shopping! Clothes, shoes, cosmetic shops.\n\n";
			break;

		case(sportSpa) :
			cout << "\aYou are on the fourth floor!";
			cout << "\nThere you can go to the swimming pool, rink, gym, or spa-salon!\n\n";
			break;

		case(clubRestaurantBar) :
			cout << "\aYou are on the fifth floor!";
			cout << "\nYou can go there to the night club, bar or to the restaurant!\n\n";
			break;

		default: cout << "\a\a\aError! We have just floors!\n\n";
		}

		cout << "If you want to exit on this floor, input 0.\n";
		cout << "if you want to continue this trop - input 1: ";
		cin >> exit;
	}
	return 0;
}