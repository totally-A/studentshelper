#include"while.cpp"
#include"dowhile.cpp"

int main()
{
	int answer;
	puts("If you want you use 'while' press 1, if you want use 'do..while' press 2:");
	scanf("%d", &answer);
	if (answer = 1)
		While();
	else if (answer = 2)
		DoWhile();
	system("pause");
}
